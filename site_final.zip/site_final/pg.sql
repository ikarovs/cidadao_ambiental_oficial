cidadao-ambiental/
├── public/
│   ├── cidadaoambiental.html
│   ├── styles.css
│   └── scripts.js
├── server.js
└── package.json